define( function ( require ) {

	"use strict";

	return {
		app_slug : 'ams-eletro-shopping',
		wp_ws_url : 'http://amseletroshopping.amstva.com/wp-appkit-api/ams-eletro-shopping',
		wp_url : 'http://amseletroshopping.amstva.com',
		theme : 'q-android',
		version : '1.0.1',
		app_type : 'phonegap-build',
		app_title : 'Eletro Shopping',
		app_platform : 'android',
		app_path: '',
		gmt_offset : -4,
		debug_mode : 'off',
		auth_key : 'PvK5P/UKPxk{R!II!!q{^wH$Mn2(^t.~K@nsx]-jepLYW y!a5){C2)&$-F>~>ox',
		options : {"refresh_interval":0},
		theme_settings : [],
		addons : []
	};

});
